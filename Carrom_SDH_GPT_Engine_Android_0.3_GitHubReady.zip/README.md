# Carrom SDH-GPT Engine 0.1
From-scratch Android proof of concept.

Implemented: vector geometry, disc/ray collision, direct shots, one-rail reflection candidates, obstacle clearance, pocket-aware scoring, and an Android Canvas trajectory renderer.

This build intentionally does NOT inject touches into a third-party game or bypass anti-cheat. The next engineering step is computer vision: board/pocket/coin detection from a supplied frame, followed by calibration and multi-rail physics.


## GitHub Actions

`.github/workflows/build-apk.yml` builds the debug APK automatically on GitHub-hosted runners and uploads `app-debug.apk` as a workflow artifact. This is included because the current local environment does not have an Android SDK/Gradle toolchain.

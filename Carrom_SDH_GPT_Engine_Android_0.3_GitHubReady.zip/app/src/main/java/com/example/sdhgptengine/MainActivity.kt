package com.example.sdhgptengine

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import kotlin.math.*

data class V(val x:Double,val y:Double) {
    operator fun plus(o:V)=V(x+o.x,y+o.y)
    operator fun minus(o:V)=V(x-o.x,y-o.y)
    operator fun times(k:Double)=V(x*k,y*k)
    fun dot(o:V)=x*o.x+y*o.y
    fun len()=hypot(x,y)
    fun n():V { val l=len(); return if(l<1e-9)V(0.0,0.0) else this*(1/l) }
}
data class Disc(val p:V,val r:Double,val id:Int)
data class Pocket(val p:V,val r:Double)
data class Shot(val pts:List<V>,val score:Double)

class Engine {
    private val left=80.0; private val top=180.0; private val right=1000.0; private val bottom=1100.0
    private val pockets=listOf(Pocket(V(left,top),30.0),Pocket(V(right,top),30.0),Pocket(V(left,bottom),30.0),Pocket(V(right,bottom),30.0))

    fun solve(striker:Disc, coins:List<Disc>):Shot? {
        var best:Shot?=null
        for(c in coins) for(pk in pockets) {
            val q=(pk.p-c.p).n()
            val contact=c.p-q*38.0
            val direct=path(striker.p,contact,c,coins,striker.id)
            if(direct!=null) {
                val s=direct.zipWithNext().sumOf{(a,b)->(b-a).len()}+(direct.last()-pk.p).len()*2
                if(best==null||s<best!!.score) best=Shot(direct,s)
            }
            for(m in listOf(
                V(2*left-contact.x,contact.y),V(2*right-contact.x,contact.y),
                V(contact.x,2*top-contact.y),V(contact.x,2*bottom-contact.y))) {
                val rail=oneRail(striker.p,m,contact,c,coins)
                if(rail!=null) {
                    val s=rail.zipWithNext().sumOf{(a,b)->(b-a).len()}+220
                    if(best==null||s<best!!.score) best=Shot(rail,s)
                }
            }
        }
        return best
    }

    private fun hit(o:V,d:V,c:Disc,clear:Double):Double? {
        val u=d.n(); val f=o-c.p; val rr=c.r+clear
        val b=2*f.dot(u); val cc=f.dot(f)-rr*rr; val det=b*b-4*cc
        if(det<0)return null
        val r=sqrt(det)
        return listOf((-b-r)/2,(-b+r)/2).filter{it>1e-5}.minOrNull()
    }

    private fun blocked(o:V,d:V,t:Double,coins:List<Disc>,ignore:Int,target:Int):Boolean =
        coins.any { it.id!=ignore && it.id!=target && (hit(o,d,it,20.0)?.let{v->v<t}==true) }

    private fun path(o:V,to:V,target:Disc,coins:List<Disc>,ignore:Int):List<V>? {
        val d=to-o; val t=hit(o,d,target,20.0) ?: return null
        if(blocked(o,d,t,coins,ignore,target.id))return null
        return listOf(o,to,target.p)
    }

    private fun oneRail(o:V,mirror:V,contact:V,target:Disc,coins:List<Disc>):List<V>? {
        val d=(mirror-o).n(); val hits=mutableListOf<Pair<Double,V>>()
        if(abs(d.x)>1e-9) for(x in listOf(left,right)){val t=(x-o.x)/d.x;val y=o.y+d.y*t;if(t>0&&y in top..bottom)hits+=t to V(x,y)}
        if(abs(d.y)>1e-9) for(y in listOf(top,bottom)){val t=(y-o.y)/d.y;val x=o.x+d.x*t;if(t>0&&x in left..right)hits+=t to V(x,y)}
        val h=hits.minByOrNull{it.first}?:return null
        if(blocked(o,d,h.first,coins,-1,target.id))return null
        return listOf(o,h.second,contact,target.p)
    }
}

class BoardView: View {
    private val p=Paint(1)
    private val engine=Engine()
    private var striker=Disc(V(540.0,930.0),18.0,0)
    private val coins=mutableListOf(
        Disc(V(540.0,620.0),18.0,1),Disc(V(500.0,650.0),18.0,2),
        Disc(V(580.0,650.0),18.0,3),Disc(V(540.0,690.0),18.0,4))
    private var shot:Shot?=null
    init { shot=engine.solve(striker,coins) }

    override fun onDraw(c:Canvas) {
        val sx=width/1080f; val sy=height/1200f; c.save(); c.scale(sx,sy)
        p.style=Paint.Style.FILL; p.color=Color.rgb(205,158,95); c.drawRect(55f,155f,1025f,1125f,p)
        p.color=Color.rgb(52,34,24); c.drawRect(80f,180f,1000f,1100f,p)
        p.color=Color.BLACK; for(x in floatArrayOf(80f,1000f)) for(y in floatArrayOf(180f,1100f)) c.drawCircle(x,y,30f,p)
        for(d in coins){p.color=if(d.id==1)Color.WHITE else Color.DKGRAY;c.drawCircle(d.p.x.toFloat(),d.p.y.toFloat(),d.r.toFloat(),p)}
        p.color=Color.rgb(30,144,255);c.drawCircle(striker.p.x.toFloat(),striker.p.y.toFloat(),18f,p)
        shot?.let{s->p.style=Paint.Style.STROKE;p.strokeWidth=7f;p.color=Color.CYAN;val path=Path();path.moveTo(s.pts[0].x.toFloat(),s.pts[0].y.toFloat());for(v in s.pts.drop(1))path.lineTo(v.x.toFloat(),v.y.toFloat());c.drawPath(path,p);p.style=Paint.Style.FILL}
        c.restore()
    }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action==MotionEvent.ACTION_UP){val x=e.x*1080/width;val y=e.y*1200/height
            striker=striker.copy(p=V(x.coerceIn(110.0,970.0),y.coerceIn(850.0,1050.0)));shot=engine.solve(striker,coins);invalidate()}
        return true
    }
}
class MainActivity:Activity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(BoardView(this))}}
